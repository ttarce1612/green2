import React from 'react';
import './App.css';

import AppContent from "./pages";

function App() {
  return (
    <div className="App">
      <AppContent />
    </div>
  );
}

export default App;
